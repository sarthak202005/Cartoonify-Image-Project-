import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

# Step 1: Read the image
def read_image(path):
    img = cv2.imread(path)
    if img is None:
        raise ValueError("Image not found at given path!")
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return img

# Step 2: Resize image for processing
def resize_image(img, width=800):
    aspect_ratio = width / img.shape[1]
    dim = (width, int(img.shape[0] * aspect_ratio))
    return cv2.resize(img, dim, interpolation=cv2.INTER_AREA)

# Step 3: Edge detection
def detect_edges(gray_img):
    gray_blur = cv2.medianBlur(gray_img, 5)
    edges = cv2.adaptiveThreshold(gray_blur, 255,
                                  cv2.ADAPTIVE_THRESH_MEAN_C,
                                  cv2.THRESH_BINARY, 9, 9)
    return edges

# Step 4: Color quantization (reduce color palette)
def color_quantization(img, k=8):
    data = np.float32(img).reshape((-1, 3))
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 0.001)
    _, labels, centers = cv2.kmeans(data, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
    centers = np.uint8(centers)
    result = centers[labels.flatten()]
    result = result.reshape(img.shape)
    return result

# Step 5: Smoothen colors
def smooth_colors(img):
    return cv2.bilateralFilter(img, d=9, sigmaColor=250, sigmaSpace=250)

# Step 6: Combine edges and smoothened image
def cartoonify_image(input_path, output_path):
    # Read and process image
    original = read_image(input_path)
    resized = resize_image(original)
    gray = cv2.cvtColor(resized, cv2.COLOR_RGB2GRAY)
    edges = detect_edges(gray)
    quantized = color_quantization(resized, k=8)
    smooth = smooth_colors(quantized)
    cartoon = cv2.bitwise_and(smooth, smooth, mask=edges)

    # Save the cartoonified image
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    cv2.imwrite(output_path, cv2.cvtColor(cartoon, cv2.COLOR_RGB2BGR))

    # Display results
    images = [original, gray, edges, quantized, smooth, cartoon]
    titles = ['Original', 'Gray', 'Edges', 'Quantized', 'Smoothed', 'Cartoon']

    plt.figure(figsize=(12, 8))
    for i in range(6):
        plt.subplot(2, 3, i + 1)
        plt.imshow(images[i], cmap='gray' if i in [1, 2] else None)
        plt.title(titles[i])
        plt.axis('off')
    plt.tight_layout()
    plt.show()

    print(f"✅ Cartoonified image saved successfully at: {output_path}")


# ---- MAIN ----
if __name__ == "__main__":
    input_path = "sample_input/your_image.jpg"   # Place your image here
    output_path = "output/cartoon_image.jpg"
    cartoonify_image(input_path, output_path)
