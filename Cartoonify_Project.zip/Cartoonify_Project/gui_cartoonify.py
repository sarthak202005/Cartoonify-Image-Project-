import cv2
import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import numpy as np
import os

def cartoonify_image(img_path):
    img = cv2.imread(img_path)
    if img is None:
        messagebox.showerror("Error", "Cannot find image!")
        return

    # Convert and resize
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img_rgb = cv2.resize(img_rgb, (800, 600))

    gray = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2GRAY)
    gray = cv2.medianBlur(gray, 5)
    edges = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                  cv2.THRESH_BINARY, 9, 9)

    # Color quantization
    data = np.float32(img_rgb).reshape((-1, 3))
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 0.001)
    _, labels, centers = cv2.kmeans(data, 8, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
    centers = np.uint8(centers)
    quantized = centers[labels.flatten()].reshape(img_rgb.shape)

    smooth = cv2.bilateralFilter(quantized, 9, 250, 250)
    cartoon = cv2.bitwise_and(smooth, smooth, mask=edges)

    output_path = "output/cartoon_output.jpg"
    os.makedirs("output", exist_ok=True)
    cv2.imwrite(output_path, cv2.cvtColor(cartoon, cv2.COLOR_RGB2BGR))

    # Display cartoon image
    img_tk = ImageTk.PhotoImage(Image.fromarray(cartoon))
    lbl_result.config(image=img_tk)
    lbl_result.image = img_tk
    messagebox.showinfo("Done", f"Cartoonified image saved at {output_path}")

def open_file():
    file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.png *.jpeg")])
    if file_path:
        cartoonify_image(file_path)

# GUI setup
root = tk.Tk()
root.title("Cartoonify an Image - IVP Project")
root.geometry("850x700")
root.config(bg="#dceafc")

lbl_title = tk.Label(root, text="Cartoonify an Image", font=("Arial", 20, "bold"), bg="#dceafc", fg="#333")
lbl_title.pack(pady=20)

btn_upload = tk.Button(root, text="Upload Image", font=("Arial", 14), bg="#4CAF50", fg="white",
                       command=open_file, padx=20, pady=10)
btn_upload.pack(pady=10)

lbl_result = tk.Label(root, bg="#dceafc")
lbl_result.pack(pady=20)

root.mainloop()
