# Cartoonify an Image 🎨

## Objective
Convert real photographs into cartoon-like images using image processing techniques.

## Techniques Used
- Bilateral Filtering
- Edge Detection
- Color Quantization (K-Means)
- Adaptive Thresholding

## Run Instructions

### Step 1: Install dependencies
```bash
pip install -r requirements.txt
